THIS TOOL IS FOR KALI LINUX AND BUILD ON PYTHON 2.7 (wont work on windows and python 3.x)



-----------------INSTALL ----------------------------------------------------------------

clone to the repo or download the files, open the directory and follow the commands
	
	# chmod +x install.sh
	# ./install.sh



-----------------------------------------------------------------------------------------
      _____           ____ _               _
     |_   _|__  _ __ / ___| |__   ___  ___| |_
       | |/ _ \| '__| |  _| '_ \ / _ \/ __| __|
       | | (_) | |  | |_| | | | | (_) \__ \ |_
       |_|\___/|_|   \____|_| |_|\___/|___/\__|
	v2.0 - SusmithHCK | www.khromozome.com 
        Hacker's QandA forum: https://www.askthehackers.com


	USAGE:
        torghost start -----(start torghost)
        torghost stop  -----(stop torghost) 
	torghost switch ----(switch IP)

    
-----------------------------------------------------------------------------------------
